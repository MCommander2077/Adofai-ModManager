import os
import sys
from source.ammpyqt.pyqtDateTime import get_date_time

obj_file = None


def log_create(filename):
    global obj_file
    obj_file = open(f"{filename}.log", "x")


def log_write(w_string, w_type):
    global obj_file
    time = get_date_time()
    obj_file.write(f"[{time[0]} {time[3]}/{w_type}]{w_string}\n")


if __name__ == "__main__":
    log_create("test1")
    log_write("1")
    log_write("2")
