from source.ammPublicAction.logAction import *

time = get_date_time()
log_create(f"{time[0]} {time[3]}")

try:
    import tkinter.messagebox as tkm
    import sys
    import os
except BaseException as error:
    log_write(f"{error}","error")
    exit(error)
log_write(f"The third-party libraries was imported successfully.","info")


try:
    import ammgui
    import ammpyqt
    import ammweb
except BaseException as error:
    tkm.showerror(title="IMPORT ERROR", message=f"{error}")
    log_write(f"{error}","error")
    exit(1)
log_write("The local libraries was imported successfully.","info")